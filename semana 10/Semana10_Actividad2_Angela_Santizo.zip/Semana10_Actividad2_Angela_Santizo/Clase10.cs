﻿class Clase10
{
    static void Main()
    {
        int[] numeros = new int[8];
        int suma = 0;

        // Solicitar el ingreso de 8 números
        Console.WriteLine("Ingrese 8 números:");
        for (int i = 0; i < 8; i++)
        {
            Console.Write($"Número {i + 1}: ");
            numeros[i] = int.Parse(Console.ReadLine());
            suma += numeros[i];
        }

        // Mostrar los números ingresados
        Console.WriteLine("Números ingresados:");
        foreach (int num in numeros)
        {
            Console.Write(num + " ");
        }
        Console.WriteLine();

        // Mostrar la suma de los números
        Console.WriteLine("Suma de los números: " + suma);

        // Calcular y mostrar el promedio
        double promedio = (double)suma / numeros.Length;
        Console.WriteLine("Promedio de los números: " + promedio);
    }
}
