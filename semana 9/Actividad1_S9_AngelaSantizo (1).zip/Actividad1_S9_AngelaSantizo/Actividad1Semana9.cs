﻿using System;

class Actividad1Semana9
{
    static void Main()
    {
        Console.Write("Ingrese un número entero positivo de hasta 6 cifras: ");
        int num;

        // Validación de entrada
        if (!int.TryParse(Console.ReadLine(), out num) || num <= 0 || num > 999999)
        {
            Console.WriteLine("Número fuera de rango. Intente nuevamente.");
            return;
        }

        // Determinar si el número es primo
        bool esPrimo = EsPrimo(num);

        if (esPrimo)
            Console.WriteLine($"El número {num} es primo.");
        else
            Console.WriteLine($"El número {num} no es primo.");
    }

    // Método para verificar si un número es primo
    static bool EsPrimo(int numero)
    {
        if (numero == 1) return false;
        if (numero == 2) return true; // Caso especial

        for (int i = 2; i * i <= numero; i++)
        {
            if (numero % i == 0)
                return false;
        }
        return true;
    }
}
