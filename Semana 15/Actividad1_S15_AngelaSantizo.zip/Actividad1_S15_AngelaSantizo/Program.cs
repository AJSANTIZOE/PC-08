﻿using System;

public class Estudiante
{
    int edad;
    string nombre;
     string carrera;
     int notaAdmision;
     string carnet;

    public static void Main()
    {
        Console.WriteLine("Actividad 1 - Semana 15 - Clases");

        Console.Write("Ingrese su Nombre: ");
        string nombreEstudiante = Console.ReadLine()!;

        Console.Write("Ingrese su Edad: ");
        int edadEstudiante = int.Parse(Console.ReadLine()!);

        Console.Write("Ingrese su Carrera: ");
        string carreraEstudiante = Console.ReadLine()!;

        Console.Write("Ingrese su Carnet: ");
        string carnetEstudiante = Console.ReadLine()!;

        Console.Write("Ingrese su Nota de Admisión: ");
        int notaEstudiante = int.Parse(Console.ReadLine()!);

        Estudiante estudiante = new Estudiante(nombreEstudiante, edadEstudiante, carreraEstudiante, carnetEstudiante, notaEstudiante);

        estudiante.MostrarResumen();

        if (estudiante.PuedeMatricular())
        {
            Console.WriteLine("El estudiante PUEDE matricularse.");
        }
        else
        {
            Console.WriteLine("El estudiante NO puede matricularse.");
        }
    }

    public Estudiante(string nombre, int edad, string carrera, string carnet, int notaAdmision)
    {
        this.nombre = nombre;
        this.edad = edad;
        this.carrera = carrera;
        this.carnet = carnet;
        this.notaAdmision = notaAdmision;
    }

    public void MostrarResumen()
    {
        Console.WriteLine("\n--- Resumen del Estudiante ---");
        Console.WriteLine($"Nombre: {nombre}");
        Console.WriteLine($"Edad: {edad}");
        Console.WriteLine($"Carrera: {carrera}");
        Console.WriteLine($"Carnet: {carnet}");
        Console.WriteLine($"Nota de Admisión: {notaAdmision}");
    }

    public bool PuedeMatricular()
    {
        return notaAdmision >= 75 && carnet.EndsWith("2025");
    }
}
