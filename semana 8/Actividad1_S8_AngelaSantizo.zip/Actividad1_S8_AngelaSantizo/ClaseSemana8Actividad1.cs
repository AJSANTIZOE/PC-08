﻿class ClaseSemana8Actividad1 
{
    public static int CalcularFactorial(int numero) //Método que calcula el factorial de un número entero
    {
        if (numero == 0)
        {
            return 1; //Devuelve 1 porque el factorial de 0 es 1
        }
        else 
        {
            int numeroFactorial = 1; //Se inicia el acumulador para el factorial
            for (int i = 1; i<= numero; i++) //Se repite hasta que sea igual al número ingresado
            {
                numeroFactorial *= i; //El acumulador se multiplica por cada secuencia
            }
            return numeroFactorial; //Devuelve el resultado final del factorial

        }
    }
    
    public static void Main() //Método principal que ejecuta el programa
    {   
        int numeroDelUsuario = 0; //Variable para almacenar el número ingresado por el usuario y ser utilizado afuera del bucle do-while
        bool validezNumero; //Variable que controla la validez de la entrada

        do //Explicación en el while
        {
            Console.Write("Ingrese un número positivo entero: "); //El usuario ingresa un número en formato string
            string entradaDeUsuario = Console.ReadLine()!; //Se lee la entrada 
 
            if (int.TryParse(entradaDeUsuario, out numeroDelUsuario)) //Intenta convertir la entrada a un número entero
            {
                if (numeroDelUsuario >= 0) //Verifica que el número es positivo o cero
                {
                    validezNumero = true; //Entrada válida

                }
                else //Si el número es negativo
                {
                    Console.WriteLine("Entrada inválida, no es un número positivo. Inténtalo de nuevo."); //Mensaje para el usuario para que sepa que ingresó un número negativo
                    validezNumero = false; //Entada inválida
                }
            }
            else //Si la conversión no pudo ser posible
            {
                Console.WriteLine("Entrada inválida, no es un número o es un número con decimales. Inténtalo de nuevo."); //Mensaje para el usuario para que sepa que ingresó un dato que no era número o era un número con decimales
                validezNumero = false; //Entada inválida
            }

            
        }
         
        while (!validezNumero); //Se ejecuta solo si el número se designa como inválido, si es válido se sale
        
        /*
        Crea una variable de resultado y su valor es el resultado de la función 
        'CalcularFactorial' en el que se ingresa como parámetro el número ingresado por el usuario
        */
        int resultadoFactorial = CalcularFactorial(numeroDelUsuario);
        Console.WriteLine($"El factorial de {numeroDelUsuario} es {resultadoFactorial}"); //Se imprime el resultado
        Console.ReadKey();

    }
}